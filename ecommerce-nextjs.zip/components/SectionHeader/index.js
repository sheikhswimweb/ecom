import classNames from "classnames";
import React from "react";
import { ChevronRightIcon } from "../base/Icons";
import Heading from "../Typography/Heading";
import Text from "../Typography/Text";

export default function SectionHeader({ title, desc, className }) {
  const cn = classNames({
    "absolute -left-4 w-2 h-full rounded-r-xl": true,
    [className]: true,
  });
  return (
    <div className="pl-4 pr-2">
      <div className="flex justify-between items-center relative pl-4">
        <div className={cn} />
        <div>
          <Heading> {title} </Heading>
          <Text>{desc}</Text>
        </div>

        <button className="flex justify-center text-xs font-medium items-center bg-white text-text-color gap-1 p-2 rounded-full">
          <span>Show More</span>
          <ChevronRightIcon />
        </button>
      </div>
    </div>
  );
}

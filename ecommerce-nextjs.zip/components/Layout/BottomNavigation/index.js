import { AccountIcon, CampaignIcon, CartIcon, HomeIcon, ProfileIcon } from '@/components/base/Icons'
import Container from '@/components/Container'
import React from 'react'
import BottomNavigationItem from './BottomNavigationItem'

export default function BottomNavigation() {
  return (
    <div className='h-16 py-2 pt-2 w-full z-50 shadow-2xl bg-white rounded-t-xl shadow-black fixed bottom-0 flex  '>
      <Container className="flex w-full">
      <BottomNavigationItem label='Home' icon={<HomeIcon />}  />
      <BottomNavigationItem label='Campaigns' icon={<CampaignIcon />}  />
      <BottomNavigationItem label='Cart' icon={<CartIcon />} badge="1"  />
      <BottomNavigationItem label='Account' icon={<AccountIcon />}  />
      </Container>
    </div>
  )
}

import React from "react";
import PropTypes from "prop-types";

export default function BottomNavigationItem(props) {
  const Icon = () => props.icon;

  return (
    <div className="h-full flex-1 flex justify-center">
      <div
        onClick={() => {
          props.onSelect && props.onSelect(props.value);
        }}
        className="w-20 h-full flex flex-col items-center justify-center gap-1 cursor-pointer relative"
      >
        {props.icon && <Icon />}
        <span className="font-medium text-xs text-text-color">
        {props.label}
        </span>

        {props.badge && (
          <div className="absolute -top-1 right-4 text-[8px] min-w-[18.8px] w-max text-white min-h-[18px] bg-app-red flex justify-center items-center p-px rounded-full">
            {props.badge}
          </div>
        )}
      </div>
    </div>
  );
}

BottomNavigationItem.propTypes = {
  icon: PropTypes.element,
  onSelect: PropTypes.func,
  className: PropTypes.string,
  value: PropTypes.string,
  active: PropTypes.bool,
  label: PropTypes.string,
  badge: PropTypes.string,
};

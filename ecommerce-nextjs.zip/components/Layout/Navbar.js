import React from 'react'
import IconButton from '../base/IconButton'
import { MenuIcon, MessageIcon } from '../base/Icons'
import Container from '../Container'
import SearchComponent from '../SearchComponent'

export default function Navbar() {
  return (
    <div className=" bg-white w-full sticky z-50 top-0 h-max pt-2">
    <Container className="flex items-center gap-4 px-4 h-full w-full justify-between">
        <IconButton icon={<MenuIcon />} />
        <SearchComponent />
        <IconButton icon={<MessageIcon />} />
    </Container>
    </div>
  )
}

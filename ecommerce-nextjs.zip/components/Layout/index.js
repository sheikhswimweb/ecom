import React from "react";
import PageWrapper from "../PageWrapper";
import BottomNavigation from "./BottomNavigation";
import Navbar from "./Navbar";

export default function Layout({ children, title, description }) {
  return (
    <PageWrapper title={title} description={description}>
      <Navbar />
      <div className="pb-28 mt-2 space-y-2">{children}</div>
      <BottomNavigation />
    </PageWrapper>
  );
}

import React from "react";
import Container from "../Container";
import { Pagination, Autoplay } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

export default function Banner() {
  return (
    <Container className="px-4">
      <div className="w-full h-32 overflow-hidden rounded-xl bg-input-background">
        <Swiper
          modules={[Pagination, Autoplay]}
          spaceBetween={0}
          className="w-full h-full"
          slidesPerView={1}
          autoplay
          loop
          pagination={{clickable: true, currentClass: "currentSlider", }}
        >
          <SwiperSlide className="relative rounded-xl">
            <img src="/assets/images/car.jpg" className="w-full h-full object-cover rounded-xl" />
            <div className="w-full h-full absolute inset-0 bg-black/30 rounded-xl" />
          </SwiperSlide>
          <SwiperSlide className="relative rounded-xl">
          <img src="/assets/images/pexels-torsten-dettlaff-193004.jpg" className="w-full h-full object-cover rounded-xl" />
            <div className="w-full h-full absolute inset-0 bg-black/30 rounded-xl" />
          </SwiperSlide>
        </Swiper>
      </div>
    </Container>
  );
}

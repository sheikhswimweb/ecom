import Head from "next/head";
import React from "react";

const defaultTitle = "Next Js App";
const defaultDesc = "This is a next js application";

export default function PageWrapper({
  children,
  title = defaultTitle,
  description = defaultDesc,
}) {
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
      </Head>
      {children}
    </>
  );
}

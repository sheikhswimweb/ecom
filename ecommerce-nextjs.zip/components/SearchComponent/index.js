import React from 'react'
import { SearchIcon } from '../base/Icons'

export default function SearchComponent() {
  return (
    <div className='bg-input-background flex flex-1 justify-center items-center p-2 px-3 rounded-full gap-2'>
        <SearchIcon className='text-xl' />
        <input placeholder='What would you like to buy?' className='flex-1 bg-transparent focus:border-none w-full focus:outline-none placeholder:text-text-color text-base placeholder:text-base' />
    </div>
  )
}

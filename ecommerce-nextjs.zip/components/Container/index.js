import classNames from "classnames";
import React from "react";

export default function Container({ children, className }) {
  const cn = classNames({
    "max-w-6xl mx-auto": true,
    [className]: true,
  });
  return <div className={cn}>{children}</div>;
}

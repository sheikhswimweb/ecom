import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

export default function IconButton(props) {

  const Icon = () => props.icon;

  if (!props.icon) {
    return <></>;
  }

  const cn = classNames({
    "flex justify-center items-center rounded-full text-3xl": true,
    [props.className]: true,
  });
  
  return (
    <button {...props} className={cn}>
      <Icon />
    </button>
  );
}

IconButton.propTypes = {
  icon: PropTypes.element,
  onClick: PropTypes.func,
  className: PropTypes.string,
};

import React from "react";

export default function Heading({ children, ...rest }) {
  return (
    <h1 className="text-base font-bold" {...rest}>
      {children}
    </h1>
  );
}
export function SubHeading({ children, ...rest }) {
  return (
    <p className="text-xs font-medium" {...rest}>
      {children}
    </p>
  );
}

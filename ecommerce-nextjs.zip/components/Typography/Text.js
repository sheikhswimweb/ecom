import React from "react";

export default function Text({ children }) {
  return <p>{children}</p>;
}

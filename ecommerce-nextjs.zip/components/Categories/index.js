import React from "react";
import { BusIcon, CategoryIcon, FavouriteIcon, HelpIcon, OrderIcon } from "../base/Icons";
import Container from "../Container";

export default function Categories() {

  return <Container>
    <div className="flex justify-between gap-2 overflow-x-auto px-4">
    <CategoriesItem label="FAQ" icon={<HelpIcon width="26" />} />
    <CategoriesItem label="Wishlist" icon={<FavouriteIcon width="26" />} />
    <CategoriesItem label="Express" icon={<BusIcon width="26" />} />
    <CategoriesItem label="Categories" icon={<CategoryIcon width="26" />} />
    <CategoriesItem label="Orders" icon={<OrderIcon width="26" />} />
  </div>
  </Container>;
}

const CategoriesItem = ({ icon, label }) => {
  const Icon = () => icon;
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="w-[54px] h-[54px] flex justify-center items-center bg-[#F2F3F5] rounded-full">{icon && <Icon />}</div>
      <span className="text-xs">{label}</span>
    </div>
  );
};

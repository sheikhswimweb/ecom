import classNames from "classnames";
import React from "react";

export default function ProductListItem({
  name = "OnePlus Nord CE 2 5G - (8GB/128GB) - Blue With Free PUBG Gaming And tHis is a test",
  price = "15,000",
  discount = "5, 000",
  imgUrl = "/assets/images/iphone.png",
  className
}) {
    const cn = classNames({
        'w-full max-h-[260px] bg-white overflow-hidden rounded-[8px] p-2 space-y-2': true,
        [className]: true
    })
  return (
    <div className={cn}>
      <img src={imgUrl} className="h-[140px] mx-auto  rounded-[8px]" />
      <div className="space-y-2">
        {name && <h5 className="font-medium text-[11px] line-clamp-3">{name}</h5>}
        {price && (
          <h6 className="font-medium text-[11px] text-text-color line-through">
            $ {discount}
          </h6>
        )}
        {discount && (
          <h6 className="font-medium text-[11px] text-app-price">$ {price}</h6>
        )}
      </div>
    </div>
  );
}

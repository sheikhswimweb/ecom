import classNames from 'classnames'
import React from 'react'

export default function Products({children, className}) {
    const cn = classNames({
        'flex gap-[6px] overflow-x-auto px-4 scrollbar-hide': true,
        [className]: true
    })
  return (
    <div className={cn}>
        {children}
    </div>
  )
}

import classNames from "classnames";
import React from "react";
import { ArrowDownIcon } from "../base/Icons";

export default function Campaigns() {
  return <div className="flex gap-4 overflow-x-auto px-4 scrollbar-hide">
    <Card title="Hot Deal" desc="Upto 37% Discount & 70% Cashback" className="bg-[#38BCC9]" />
    <Card title="prime Deal" desc="Upto 37% Discount & 70% Cashback" className="bg-[#E45B5A]" />
    <Card title="prime Deal" desc="Upto 37% Discount & 70% Cashback" className="bg-[#E45B5A]" />
  </div>;
}

const Card = ({ title, desc, className}) => {
    const cn = classNames({
        'h-20 min-w-[232px] relative flex flex-col rounded-[8px] text-white justify-center p-4': true,
        [className]: true
    })
  return (
    <div className={cn}>
      <h4 className="text-xs uppercase">{title}</h4>
      <p className="text-[11px]">{desc}</p>
      <button className="absolute top-2 right-2">
        <ArrowDownIcon />
      </button>
    </div>
  );
};

import Banner from "@/components/Banner";
import Campaigns from "@/components/Campaigns";
import Categories from "@/components/Categories";
import Container from "@/components/Container";
import Layout from "@/components/Layout";
import Products from "@/components/Products";
import ProductItem from "@/components/Products/ProductItem";
import ProductListItem from "@/components/Products/ProductListItem";
import SectionHeader from "@/components/SectionHeader";
import Heading from "@/components/Typography/Heading";

export default function Home() {
  return (
    <Layout title="This is a test" description="Nice">
      <Banner />
      <Categories />
      <div>
      <div className="bg-app-background mt-6 py-4 rounded-t-3xl  space-y-4">
        <Container className="space-y-4">
          <SectionHeader
            className="bg-app-pale-green"
            title="Ongoing Campaigns"
            desc="Enjoy Pick and Pay"
          />

          <Campaigns />
        </Container>

        <Container className="space-y-4">
          <SectionHeader
            className="bg-app-purple"
            title="Mega Quick Deal"
            desc="Exclusive offers!"
          />
          <Products>
            <ProductItem />
            <ProductItem />
            <ProductItem />
            <ProductItem />
            <ProductItem />
          </Products>
        </Container>
        <Container className="space-y-4">
          <SectionHeader
            className="bg-app-yellow"
            title="Hotel & Tours Deals"
            desc="Best Deals Ever!"
          />
          <Products>
            <ProductItem />
            <ProductItem />
            <ProductItem />
            <ProductItem />
            <ProductItem />
          </Products>
        </Container>
        <Container className="space-y-4">
          <SectionHeader
            className="bg-app-orange"
            title="PNP Shops"
            desc="Enjoy Exclusive Products"
          />
          <Products>
            <ProductItem fullImage price="" discount="" imgUrl="/assets/images/realme.jpg" name="Geo Phone for COD" />
            <ProductItem fullImage price="" discount="" imgUrl="/assets/images/realme.jpg" name="Jumana Electronics for ." />
            <ProductItem fullImage price="" discount="" imgUrl="/assets/images/realme.jpg" name="Contrivanace Distribution" />
          </Products>
        </Container>
        <Container className="space-y-4">
          <div className="px-4">
          <Heading>Products</Heading>
          </div>
          <div className="grid grid-cols-2 scrollbar-hide gap-2 px-4 md:grid-cols-3 lg:grid-cols-4">
            <ProductListItem />
            <ProductListItem />
            <ProductListItem />
          </div>
        </Container>
      </div>
      </div>
    </Layout>
  );
}

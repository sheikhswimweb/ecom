/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'input-background': '#F2F3F5',
        'app-red': "#AF001D",
        'text-color': "#828282",
        'app-yellow': "#D6E18C",
        'app-pale': "#0DA6A2",
        'app-pale-green': '#07BF87',
        'app-orange': '#FF9700',
        'app-price': "#E47634",
        'app-background': '#F9F9F9',
        'app-purple': "#B2C5FD"
      }
    },
  },
  plugins: [
    require('tailwind-scrollbar-hide'),
    require('@tailwindcss/line-clamp'),
  ],
}
